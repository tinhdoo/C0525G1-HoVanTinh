package phone_management.view;

import phone_management.controller.PhoneController;

public class Main {
    public static void main(String[] args) {
        new PhoneController().phoneManager();
    }

}